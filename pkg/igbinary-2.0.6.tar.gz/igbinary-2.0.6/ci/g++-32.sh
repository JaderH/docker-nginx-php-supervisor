#!/bin/sh
exec g++-4.8 -m32 "$@"
